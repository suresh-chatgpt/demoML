import 'dart:io';

import 'package:flutter/material.dart';
import 'package:google_mlkit_text_recognition/google_mlkit_text_recognition.dart';
import 'package:image_picker/image_picker.dart';

class Demo_Ml extends StatefulWidget {
  //const Demo_Ml({ Key? key }) : super(key: key);

  @override
  State<Demo_Ml> createState() => _Demo_MlState();
}

class _Demo_MlState extends State<Demo_Ml> {
  bool textScanning = false;
  XFile? imageFile;
  String scannedText = "";
  pickImageFromGallery() async {
    try {
      final pickedImage =
          await ImagePicker().pickImage(source: ImageSource.gallery);
      if (pickedImage != null) {
        setState(() {
          imageFile = pickedImage;
        });
        getRecognisedText(imageFile!);
      }
    } catch (e) {
      setState(() {
        textScanning = false;
        imageFile = null;
        scannedText = "Error occured while scanning";
      });
    }
  }

  pickImageFromCamera() async {
    try {
      final pickedImage =
          await ImagePicker().pickImage(source: ImageSource.camera);
      if (pickedImage != null) {
        setState(() {
          imageFile = pickedImage;
        });
        getRecognisedText(imageFile!);
      }
    } catch (e) {
      setState(() {
        textScanning = false;
        imageFile = null;
        scannedText = "Error occured while scanning";
      });
    }
  }

  getRecognisedText(XFile image) async {
    final inputImage = InputImage.fromFilePath(image.path);
    final textDetector = TextRecognizer();
    RecognizedText recognizedText = await textDetector.processImage(inputImage);
    // await textDetector.close();
    var resultText = "";
    for (TextBlock block in recognizedText.blocks) {
      for (TextLine line in block.lines) {
        // for (TextElement element in line.elements) {
        //   resultText += element.text + " ";
        // }
        resultText += line.text + "\n";
      }
      // resultText += "\n";
    }
    setState(() {
      textScanning = false;
      scannedText = resultText;
    });
    print(scannedText);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: SafeArea(
            child: Container(
      padding: EdgeInsets.all(20),
      child: Column(
        children: [
          !textScanning && imageFile != null
              ? Container(
                  height: 300,
                  child: Image.file(File(imageFile!.path)),
                )
              : textScanning
                  ? Container(
                      color: Colors.white,
                      alignment: Alignment.center,
                      height: 300,
                      child: CircularProgressIndicator(
                        color: Colors.blue,
                      ),
                    )
                  : Container(
                      alignment: Alignment.center,
                      height: 300,
                      color: Colors.grey[200],
                      child: Text("No Image")),
          SizedBox(
            height: 10,
          ),
          Row(mainAxisAlignment: MainAxisAlignment.center, children: [
            Container(
              width: 100,
              height: 30,
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: Color(0xFF0170d0))),
              child: ElevatedButton(
                onPressed: () {
                  pickImageFromGallery();
                  setState(() {
                    textScanning = true;
                  });
                },
                child: Text(
                  "Gallery",
                  style: TextStyle(color: Colors.white, fontSize: 11),
                ),
                style: ElevatedButton.styleFrom(
                    primary: Color(0xFF0170d0),
                    //  primary: Color(0xFF0170d0),
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(20))),
              ),
            ),
            SizedBox(width: 5),
            Container(
              width: 100,
              height: 30,
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: Colors.purple)),
              child: ElevatedButton(
                onPressed: () {
                  pickImageFromCamera();
                  setState(() {
                    textScanning = true;
                  });
                },
                child: Text(
                  "Camera",
                  style: TextStyle(color: Colors.white, fontSize: 11),
                ),
                style: ElevatedButton.styleFrom(
                    primary: Colors.purple,
                    //  primary: Color(0xFF0170d0),
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(20))),
              ),
            )
          ]),
          SizedBox(
            height: 10,
          ),
          Container(
              width: MediaQuery.of(context).size.width * 0.8,
              child: Text("$scannedText"))
        ],
      ),
    )));
  }
}
